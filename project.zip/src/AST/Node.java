package AST;

public abstract class Node {
    public int line;
    public String name;

    public Node(int line, String name ) {
        this.line = line;
        this.name = name;
    }

    @Override
    public String toString() {
        String RED = "\u001B[31m";
        String RESET = "\u001B[0m";
        String GREEN  = "\u001B[32m";
        return RED + "line" +this.line + "- "+ GREEN + this.name + " " + RESET;
    }

}

