package Visitor;

import AST_Python.*;
import AST_Python.compound_statements.*;
import AST_Python.expressions.*;
import AST_Python.expressions.atoms.*;
import AST_Python.expressions.compare.*;
import AST_Python.small_statements.*;
import SymbolTable.SymbolTable;
import SymbolTable.SymbolKind;

public class SymbolTableBuilder implements ASTVisitor<Void> {
    private final SymbolTable symbolTable = new SymbolTable();

    public SymbolTable getSymbolTable() {
        return symbolTable;
    }

    @Override
    public Void visit(Program node) {
        for (Statement statement : node.getStatements()) {
            statement.accept(this);
        }
        return null;
    }

    @Override
    public Void visit(Body node) {
        for (Statement statement : node.getStatements()) {
            statement.accept(this);
        }
        return null;
    }

    @Override
    public Void visit(FunctionStatement node) {
        symbolTable.define(node.getName(), null, null, SymbolKind.FUNCTION, node.getLine(), false);
        symbolTable.enterScope(node.getName());
        for (Parameter parameter : node.getParameters()) {
            parameter.accept(this);
        }
        node.getBody().accept(this);
        symbolTable.exitScope();
        return null;
    }

    @Override
    public Void visit(IfStatement node) {
        node.getCondition().accept(this);
        node.getIfBody().accept(this);
        for (ElseIfStatement elseIfStatement : node.getElseIfStatements()) {
            elseIfStatement.accept(this);
        }
        if (node.getElseBody() != null) {
            node.getElseBody().accept(this);
        }
        return null;
    }

    @Override
    public Void visit(WithStatement node) {
        node.getExpression().accept(this);

        if (node.getBody() != null) {
            node.getBody().accept(this);
        }

        return null;
    }

    @Override
    public Void visit(AssignStatement node) {
        Expression leftExpression = node.getLeftExpression();
        leftExpression.accept(this);

        return null;
    }

    @Override
    public Void visit(GlobalStatement node) {
        return null;
    }

    @Override
    public Void visit(ReturnStatement node) {
        return null;
    }

    @Override
    public Void visit(NameAtom node) {
        return null;
    }

    @Override
    public Void visit(IntegerAtom node) {
        return null;
    }

    @Override
    public Void visit(FloatAtom node) {
        return null;
    }

    @Override
    public Void visit(StringAtom node) {
        return null;
    }

    @Override
    public Void visit(DecoratedFunction node) {
        return null;
    }

    @Override
    public Void visit(Decorator node) {
        return null;
    }

    @Override
    public Void visit(ElseIfStatement node) {
        return null;
    }

    @Override
    public Void visit(DictionaryAtom node) {
        return null;
    }

    @Override
    public Void visit(FalseAtom node) {
        return null;
    }

    @Override
    public Void visit(GroupingAtom node) {
        return null;
    }

    @Override
    public Void visit(ListAtom node) {
        return null;
    }

    @Override
    public Void visit(ListComprehensionAtom node) {
        return null;
    }

    @Override
    public Void visit(NoneAtom node) {
        return null;
    }

    @Override
    public Void visit(TrueAtom node) {
        return null;
    }

    @Override
    public Void visit(CompareEqual node) {
        return null;
    }

    @Override
    public Void visit(CompareGreaterThan node) {
        return null;
    }

    @Override
    public Void visit(CompareGreaterThanEqual node) {
        return null;
    }

    @Override
    public Void visit(CompareIn node) {
        return null;
    }

    @Override
    public Void visit(CompareLessThan node) {
        return null;
    }

    @Override
    public Void visit(CompareLessThanEqual node) {
        return null;
    }

    @Override
    public Void visit(CompareNotEqual node) {
        return null;
    }

    @Override
    public Void visit(CompareNotIn node) {
        return null;
    }

    @Override
    public Void visit(AccessAttributeExpression node) {
        return null;
    }

    @Override
    public Void visit(AccessFunctionExpression node) {
        return null;
    }

    @Override
    public Void visit(AccessSubscriptExpression node) {
        return null;
    }

    @Override
    public Void visit(Addition node) {
        return null;
    }

    @Override
    public Void visit(AndExpression node) {
        return null;
    }

    @Override
    public Void visit(AssignExpression node) {
        return null;
    }

    @Override
    public Void visit(Atom node) {
        return null;
    }

    @Override
    public Void visit(CompareExpression node) {
        return null;
    }

    @Override
    public Void visit(Comparision node) {
        return null;
    }

    @Override
    public Void visit(DictionaryEntry node) {
        return null;
    }

    @Override
    public Void visit(Division node) {
        return null;
    }

    @Override
    public Void visit(DottedName node) {
        return null;
    }

    @Override
    public Void visit(Multiplication node) {
        return null;
    }

    @Override
    public Void visit(NotExpression node) {
        return null;
    }

    @Override
    public Void visit(NumbericExpression node) {
        return null;
    }

    @Override
    public Void visit(OrExpression node) {
        return null;
    }

    @Override
    public Void visit(Subtraction node) {
        return null;
    }

    @Override
    public Void visit(AugmentedMinus node) {
        return null;
    }

    @Override
    public Void visit(AugmentedPlus node) {
        return null;
    }

    @Override
    public Void visit(ExpressionStatement node) {
        return null;
    }

    @Override
    public Void visit(FromImport node) {
        return null;
    }

    @Override
    public Void visit(ImportStatement node) {
        return null;
    }

    @Override
    public Void visit(PlainImport node) {
        return null;
    }

    @Override
    public Void visit(CompoundStatement node) {
        return null;
    }

    @Override
    public Void visit(Expression node) {
        return null;
    }

    @Override
    public Void visit(Node node) {
        return null;
    }

    @Override
    public Void visit(Parameter node) {
        return null;
    }

    @Override
    public Void visit(SimpleStatement node) {
        return null;
    }

    @Override
    public Void visit(SmallStatement node) {
        return null;
    }

    @Override
    public Void visit(Statement node) {
        return null;
    }

    @Override
    public Void visit(TargetExpression node) {
        return null;
    }

    @Override
    public Void visit(ValueExpression node) {
        return null;
    }
}
