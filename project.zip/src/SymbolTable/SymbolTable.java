package SymbolTable;

import java.io.PrintStream;
import java.util.*;

/**
 * SymbolTable
 */
public class SymbolTable {

    private final Scope globalScope;
    private final Deque<Scope> scopeStack = new ArrayDeque<>();
    private final List<Scope> allScopes = new ArrayList<>();

    public SymbolTable() {
        globalScope = new Scope("global", null);
        pushScope(globalScope);
    }

    private void pushScope(Scope scope) {
        scopeStack.push(scope);
        allScopes.add(scope);
    }

    public void enterScope(String name) {
        Scope newScope = new Scope(name, currentScope());
        pushScope(newScope);
    }

    public void exitScope() {
        if (scopeStack.size() > 1) {
            scopeStack.pop();
        }
    }

    public Scope currentScope() {
        return scopeStack.peek();
    }

    public Symbol define(String name,String type, String value, SymbolKind kind, int line, boolean isGlobal) {
        return currentScope().define(name,type,value, kind, line, isGlobal);
    }

    public Symbol defineInGlobal(String name,String type, String value, SymbolKind kind, int line, boolean isGlobal) {
        return globalScope.define(name, type,value,kind, line, isGlobal);
    }

    public Scope getGlobalScope() {
        return globalScope;
    }

    public List<Scope> getAllScopes() {
        return Collections.unmodifiableList(allScopes);
    }

    public Symbol lookup(String name) {
        Symbol latest = null;
        for (Scope scope : scopeStack) {
            for (Symbol symbol : scope.getSymbols()) {
                if (symbol.getName().equals(name)) {
                    if (latest == null || latest.getLine() < symbol.getLine()) {
                        latest = symbol;
                    }
                }
            }
        }
        return latest;
    }

    public void addParameter(String name, String parameter) {
        for (Scope scope : scopeStack) {
            for (Symbol symbol : scope.getSymbols()) {
                if (symbol.getName().equals(name)) {
                    symbol.addParameter(parameter);
                }
            }
        }
    }

    public Symbol lookupGlobal(String name) {
        Symbol latest = null;

        for (Symbol symbol : globalScope.getSymbols()) {
            if (symbol.getName().equals(name)) {
                if (latest == null || latest.getLine() < symbol.getLine()) {
                    latest = symbol;
                }
            }
        }
        return latest;
    }

    // ── print ─────────────────────────────────────────────────────────────────

    public void print(PrintStream out) {
        final int W = 90; // wider to fit TYPE column
        final String TOP = "╔" + "═".repeat(W + 2) + "╗";
        final String BOTTOM = "╚" + "═".repeat(W + 2) + "╝";
        final String DIV = "╠" + "═".repeat(W + 2) + "╣";
        final String BLANK = "║" + " ".repeat(W + 2) + "║";
        final String INNER = "─".repeat(W - 4);

        out.println(TOP);
        out.println(centre("SYMBOL TABLE", W));
        out.println(DIV);

        for (int i = 0; i < allScopes.size(); i++) {
            Scope scope = allScopes.get(i);

            String parentInfo = scope.getParent() != null
                    ? "  (parent: " + scope.getParent().getName() + ")" : "";

            out.println(left("  SCOPE: " + scope.getName() + parentInfo, W));

            Collection<Symbol> symbols = scope.getSymbols();

            if (symbols.isEmpty()) {
                out.println(left("    (empty scope)", W));
            } else {
                out.println("║  ┌" + INNER + "┐  ║");

                // UPDATED HEADER
                out.println(row("NAME", "KIND", "TYPE", "VALUE","LINE", "ISGLOBAL", W));

                out.println("║  ├" + INNER + "┤  ║");

                for (Symbol sym : symbols) {
                    out.println(row(
                            sym.getName(),
                            sym.getKind().name(),
                            sym.getType(),
                            sym.getValue(),
                            String.valueOf(sym.getLine()),
                            String.valueOf(sym.isGlobal()),
                            W
                    ));
                }

                out.println("║  └" + INNER + "┘  ║");
            }

            if (i < allScopes.size() - 1) out.println(BLANK);
        }

        out.println(BOTTOM);
    }

    // ── formatting helpers ────────────────────────────────────────────────────

    private static String row(
            String name,
            String kind,
            String type,
            String value,
            String line,
            String isGlobal,
            int W
    ) {
        int innerW = W - 4;

        String cell = String.format("  %-18s %-15s %-15s %-15s %-10s %-12s",
                name, kind, type, value, line, isGlobal);

        if (cell.length() > innerW) {
            cell = cell.substring(0, innerW);
        }

        return "║  │" + String.format("%-" + innerW + "s", cell) + "│  ║";
    }
    private static String centre(String text, int W) {
        int pad = (W - text.length()) / 2;
        return "║" + String.format("%-" + W + "s",
                " ".repeat(Math.max(pad, 0)) + text) + "  ║";
    }

    private static String left(String text, int W) {
        return "║" + String.format("%-" + W + "s", text) + "  ║";
    }
}